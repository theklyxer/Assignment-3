#ifndef CPUSTAT_H
#define CPUSTAT_H

struct CPUStat {
    int pid;        // Process ID
    int burst;      // Current burst number
    int start_time; // Start time of the burst
    int end_time;   // End time of the burst
};


#endif // MAIN_H
