#ifndef RR1CPU_H
#define RR1CPU_H
#include <bits/stdc++.h>
using namespace std;
// Function declaration
void runRR1Cpu(const std::string& workloadFile);
void RR1(map<int, string> &names, vector<vector<int>> &data);

#endif // MAIN_H
