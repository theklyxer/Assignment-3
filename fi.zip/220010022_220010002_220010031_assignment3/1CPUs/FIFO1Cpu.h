#ifndef FIFO1CPU_H
#define FIFO1CPU_H
#include <bits/stdc++.h>
using namespace std;
// Function declaration
void runFIFO1Cpu(const std::string& workloadFile);
void fifo1(map<int, string>& names, vector<vector<int>>& data);

#endif // MAIN_H
