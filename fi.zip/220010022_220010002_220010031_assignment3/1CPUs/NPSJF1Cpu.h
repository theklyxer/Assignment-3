#ifndef NPSJF1CPU_H
#define NPSJF1CPU_H
#include <bits/stdc++.h>
using namespace std;
// Function declaration
void runNPSJF1Cpu(const std::string& workloadFile);
void nonpremsjf1(map<int, string>& names, vector<vector<int>>& data);

#endif // MAIN_H
