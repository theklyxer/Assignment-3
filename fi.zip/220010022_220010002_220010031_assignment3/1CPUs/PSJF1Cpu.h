#ifndef PSJF1CPU_H
#define PSJF1CPU_H
#include <bits/stdc++.h>
#include "../CPUStat.h"
using namespace std;

// Function declaration


void runPSJF1Cpu(const std::string& workloadFile);
vector<vector<int>> premsjf1(map<int, string>& names, vector<vector<int>>& data,
                            vector<CPUStat>& cpu0_stats);

#endif // MAIN_H
