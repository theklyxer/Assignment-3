#ifndef parseLine1_H
#define parseLine1_H
#include <bits/stdc++.h>
using namespace std;
// Function declaration
vector<int> parseLine1(const string& line);

#endif // MAIN_H
