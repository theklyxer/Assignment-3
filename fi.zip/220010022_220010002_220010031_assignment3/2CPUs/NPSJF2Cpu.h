#ifndef NPSJF2CPU_H
#define NPSJF2CPU_H
#include <bits/stdc++.h>
using namespace std;
// Function declaration
void runNPSJF2Cpu(const std::string& workloadFile);
vector<vector<int>> Npremsjf2(map<int, string>& names, vector<vector<int>>& data);

#endif // MAIN_H
