#ifndef PSJF2CPU_H
#define PSJF2CPU_H
#include "../CPUStat.h"
#include <bits/stdc++.h>
using namespace std;
// Function declaration
void runPSJF2Cpu(const std::string& workloadFile);
vector<vector<int>> premsjf2(map<int, string>& names, vector<vector<int>>& data,
                            vector<CPUStat>& cpu0_stats, vector<CPUStat>& cpu1_stats);

#endif // MAIN_H