#ifndef FIFO2CPU_H
#define FIFO2CPU_H
#include <bits/stdc++.h>
using namespace std;
// Function declaration
void runFIFO2Cpu(const std::string& workloadFile);
vector<vector<int>> fifo2(map<int, string>& names, vector<vector<int>>& data);

#endif // MAIN_H
