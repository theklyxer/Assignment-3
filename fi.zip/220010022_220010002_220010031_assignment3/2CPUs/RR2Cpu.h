#ifndef RR2CPU_H
#define RR2CPU_H
#include <bits/stdc++.h>
using namespace std;
// Function declaration
void runRR2Cpu(const std::string& workloadFile);
void RR2(map<int, string>& names, vector<vector<int>>& data);

#endif // MAIN_H
