#ifndef parseLine2_H
#define parseLine2_H
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>  // For sorting
#include <map>  // For maps
#include <queue>  // For queues
#include <iostream>
using namespace std;
// Function declaration
vector<int> parseLine2(const string& line);

#endif // MAIN_H
